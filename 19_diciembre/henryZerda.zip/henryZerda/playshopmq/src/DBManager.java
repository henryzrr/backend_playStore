import java.util.LinkedList;
import java.util.List;

public class DBManager {
    public DBManager(){

    }
    public List<Integer> getSuscribedUsers(){
        List<Integer> users = new LinkedList<>();
        users.add(1);
        return users;
    }

}
