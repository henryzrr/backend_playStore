import phone.PhoneKernel;

public class Main {
    public static void main(String []args){
        PhoneKernel phoneKernel = new PhoneKernel();
    }
}
